import './App.css'; 
import Detail from './Detail';
import Footer from './components/Footer'; // Footer 컴포넌트 import

function App() {
  return (
    <div className="App">
      <Detail />
      <Footer />  {/* 페이지 아래 푸터 삽입 */}
    </div>
  );
}

export default App;
