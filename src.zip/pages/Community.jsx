import { useState } from "react";
import "./css/Community.css"; // ← CSS 위치에 맞게 수정

const Community = () => {
  // 글쓰기 드롭다운 상태
  const [selectedWrite, setSelectedWrite] = useState("전체글");
  const [isOpenWrite, setIsOpenWrite] = useState(false);

  // 검색 드롭다운 상태
  const [selectedSearch, setSelectedSearch] = useState("전체글");
  const [isOpenSearch, setIsOpenSearch] = useState(false);

  const writeOptions = ["전체글", "내가 작성한 글"];
  const searchOptions = ["제목", "작성자", "내용", "전체글"];
  return (
    <div id="community">
      <div id="co_title">
        <h1>게시판</h1>
        <div className="co_moveButton">
          <div>
            <a href="#none">Q&amp;A</a>
          </div>
          <div>
            <a href="#none">문의하기</a>
          </div>
          <div>
            <a href="#none">자주하는 질문</a>
          </div>
        </div>
      </div>

      <div id="co_wrtingButton">
        <div className="co_wholewirte">
          <div className="co_drop" onClick={() => setIsOpenWrite(!isOpenWrite)}>
            <span className="co_label">{selectedWrite}</span>
            <span className="bxs--down-arrow"></span>
          </div>

          {/* 옵션 리스트 */}
          {isOpenWrite && (
            <ul className="co_himdel">
              {writeOptions
                .filter((opt) => opt !== selectedWrite)
                .map((opt) => (
                  <li
                    key={opt}
                    onClick={() => {
                      setSelectedWrite(opt);
                      setIsOpenWrite(false);
                    }}
                  >
                    {opt}
                  </li>
                ))}
            </ul>
          )}

          {/* <ul className="co_himdel">
            <li>전체글 </li>
            <li>내가 작성한 글</li>
          </ul> */}
        </div>
        <a href="#none" className="co_write">
          글쓰기
        </a>
      </div>

      <div id="co_bullSection">
        <div className="co_boardHeader">
          <div>번호</div>
          <div>상품정보</div>
          <div>제목</div>
          <div>작성자</div>
          <div>작성일</div>
          <div>조회</div>
        </div>

        <article className="co_review">
          <div className="co_number">001</div>
          <div className="co_product">
            <a href="#none" className="thumb">
              <img src="/img/co_img01.png" alt="co_img01" />
            </a>
          </div>
          <a href="#none" className="co_boardTitle">
            <strong>꽃이 실제보다 너무 작아서 실망입니다.</strong>
            <p>
              아니 꽃을 샀는데…
              <br />
              실제 사진보다 너무 작아서 좀 그렇습니다…
              <br />
              이건 좀 슬픕니다.
            </p>
            <br />
          </a>
          <div className="co_name">박○○</div>
          <div className="co_date">25.00.00</div>
          <div className="co_views">33</div>
        </article>

        <article className="co_review">
          <div className="co_number">002</div>
          <div className="co_product">
            <a href="#none" className="thumb">
              <img src="/img/co_img02.png" alt="co_img02" />
            </a>
          </div>
          <a href="#none" className="co_boardTitle">
            <strong>화병 짱 예쁨</strong>
            <p>
              내 화분을 바라봐
              <br />
              넌 내 꽃에 빠져
              <br />
              끝.
            </p>
            <br />
          </a>
          <div className="co_name">장○○</div>
          <div className="co_date">25.00.00</div>
          <div className="co_views">173</div>
        </article>

        <article className="co_review">
          <div className="co_number">003</div>
          <div className="co_product">
            <a href="#none" className="thumb">
              <img src="/img/co_img03.png" alt="co_img03" />
            </a>
          </div>
          <a href="#none" className="co_boardTitle">
            <strong>꽃이 진짜 너무 예뻐요!</strong>
            <p>
              고양이는 자랑이냐구요?
              <br />
              맞습니다! 잇힝 고양이 없는 사람 누구?
              <br />난 고양이 있다.
            </p>
            <br />
          </a>
          <div className="co_name">박○○</div>
          <div className="co_date">25.00.00</div>
          <div className="co_views">1004</div>
        </article>

        <article className="co_review">
          <div className="co_number">004</div>
          <div className="co_product">
            <a href="#none" className="thumb">
              <img src="/img/co_img04.png" alt="co_img04" />
            </a>
          </div>
          <a href="#none" className="co_boardTitle">
            <strong>실제로 보니까 진짜 더 예뻐요</strong>
            <p>
              분홍꽃이 역시 제일 예쁩니다.
              <br />
              종종 이용하겠습니다.
              <br />
              핀아 화이팅~
            </p>
            <br />
          </a>
          <div className="co_name">전○○</div>
          <div className="co_date">25.00.00</div>
          <div className="co_views">50</div>
        </article>

        <article className="co_review">
          <div className="co_number">005</div>
          <div className="co_product">
            <a href="#none" className="thumb">
              <img src="/img/co_img05.png" alt="co_img05" />
            </a>
          </div>
          <a href="#none" className="co_boardTitle">
            <strong>산책하다 찍은 벚꽃 사진입니다.</strong>
            <p>
              산책하다가 꽃을 찍었읍니다.
              <br />
              활짝 핀 이 꽃처럼 모두에게도 행복한 날만 있기를......
              <br />
              모두....행복합시다...!
            </p>
            <br />
          </a>
          <div className="co_name">박○○</div>
          <div className="co_date">25.00.00</div>
          <div className="co_views">24</div>
        </article>

        <div className="co_search">
          <div className="co_searchTitle">
            {/* 검색 옵션 드롭다운 */}
            <div
              className="co_optionSee"
              onClick={() => setIsOpenSearch(!isOpenSearch)}
            >
              <p>{selectedSearch}</p>
              <span className="bxs--down-arrow"></span>
            </div>

            {isOpenSearch && (
              <ul className="co_options">
                {searchOptions
                  .filter((opt) => opt !== selectedSearch)
                  .map((opt) => (
                    <li
                      key={opt}
                      onClick={() => {
                        setSelectedSearch(opt);
                        setIsOpenSearch(false);
                      }}
                    >
                      {opt}
                    </li>
                  ))}
              </ul>
            )}
          </div>

          <input
            type="text"
            className="co_searchInput"
            placeholder="내용을 입력하세요"
          />
          <button className="co_searchBtn">검색</button>
        </div>

        <div className="co_page">
          <ul>
            <li>
              <a href="#none">&lt;&lt;</a>
            </li>
            <li>
              <a href="#none">&lt;</a>
            </li>
            <li>
              <a href="#none">1</a>
            </li>
            <li>
              <a href="#none">2</a>
            </li>
            <li>
              <a href="#none">3</a>
            </li>
            <li>
              <a href="#none">4</a>
            </li>
            <li>
              <a href="#none">5</a>
            </li>
            <li>
              <a href="#none">&gt;</a>
            </li>
            <li>
              <a href="#none">&gt;&gt;</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Community;
