import products from "../data/CategoryDetailProduct";
import "./css/CategoryDetail.css";

import { useState } from "react";
// public/img 에 있는 파일을 안전하게 참조

function CategoryDetail() {
  const [sections, setSections] = useState({
    price: false,
    size: false,
    level: false,
  });

  const toggleSection = (key) =>
    setSections((prev) => ({ ...prev, [key]: !prev[key] }));
  return (
    <>
      {/* 타이틀 */}
      <div id="ca_title">
        <h1>꽃&nbsp;&nbsp;&gt;&nbsp;&nbsp;꽃다발</h1>
      </div>

      {/* 섹션 */}
      <div id="ca_section01">
        {/* 필터 영역 */}
        <div className="ca_filter">
          {/* 가격 */}
          <div className="ca_price ca_arco">
            <button
              type="button"
              className="check_price check_title"
              onClick={() => toggleSection("price")}
            >
              가격 <span class="bx--down-arrow"></span>
            </button>

            <ul className={`caPanel ${sections.price ? "open" : ""}`}>
              <li>
                <label>
                  <input type="checkbox" />
                  5만원 이상
                </label>
              </li>
              <li>
                <label>
                  <input type="checkbox" />3 ~ 5만원
                </label>
              </li>
              <li>
                <label>
                  <input type="checkbox" />
                  3만원 이하
                </label>
              </li>
            </ul>
          </div>

          {/* 크기 */}
          <div className="ca_size ca_arco">
            <button
              type="button"
              className="check_size check_title"
              onClick={() => toggleSection("size")}
            >
              크기<span class="bx--down-arrow"></span>
            </button>

            <ul className={`caPanel ${sections.size ? "open" : ""}`}>
              <li>
                <label>
                  <input type="checkbox" />
                  50cm 이상
                </label>
              </li>
              <li>
                <label>
                  <input type="checkbox" />
                  20cm ~ 50cm
                </label>
              </li>
              <li>
                <label>
                  <input type="checkbox" />
                  20cm 이하
                </label>
              </li>
            </ul>
          </div>

          {/* 난이도 */}
          <div className="ca_level ca_arco">
            <button
              type="button"
              className="check_level check_title"
              onClick={() => toggleSection("level")}
            >
              난이도<span class="bx--down-arrow"></span>
            </button>
            <ul className={`caPanel ${sections.level ? "open" : ""}`}>
              <li>
                <label>
                  <input type="checkbox" />상
                </label>
              </li>
              <li>
                <label>
                  <input type="checkbox" />중
                </label>
              </li>
              <li>
                <label>
                  <input type="checkbox" />하
                </label>
              </li>
            </ul>
          </div>
        </div>

        {/* 상품 리스트 */}
        <div className="ca_products">
          {products
            .reduce((rows, product, idx) => {
              if (idx % 3 === 0) rows.push([]);
              rows[rows.length - 1].push(product);
              return rows;
            }, [])
            .map((row, rowIdx) => (
              <div
                key={rowIdx}
                className={`ca_products0${rowIdx + 1} ca_prostyle`}
              >
                {row.map((product, idx) => (
                  <>
                    <div className="product_card">
                      <img src={`/img/${product.img}`} alt={product.name} />
                      <p className="product_name">{product.name}</p>
                      <p className="product_price">{product.price}</p>
                      <div className="ca_line"></div>
                    </div>

                    {/* 마지막 카드가 아닐 때만 widthLine 출력 */}
                    {idx !== row.length - 1 && (
                      <div className="ca_widthLine"></div>
                    )}
                  </>
                ))}
              </div>
            ))}

          {/* 페이지네이션 */}
          <div className="ca_page">
            <ul>
              <li>
                <button type="button" className="linklike">
                  &lsaquo;&lsaquo;
                </button>
              </li>
              <li>
                <button type="button" className="linklike">
                  &lsaquo;
                </button>
              </li>
              <li>
                <button type="button" className="linklike">
                  1
                </button>
              </li>
              <li>
                <button type="button" className="linklike">
                  2
                </button>
              </li>
              <li>
                <button type="button" className="linklike">
                  3
                </button>
              </li>
              <li>
                <button type="button" className="linklike">
                  4
                </button>
              </li>
              <li>
                <button type="button" className="linklike">
                  5
                </button>
              </li>
              <li>
                <button type="button" className="linklike">
                  &rsaquo;
                </button>
              </li>
              <li>
                <button type="button" className="linklike">
                  &rsaquo;&rsaquo;
                </button>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}

export default CategoryDetail;
