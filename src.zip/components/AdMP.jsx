import React from "react";
import "./css/AdMP.css";

const AdMP = () => {
  return <div id="adMP"></div>;
};

export default AdMP;
