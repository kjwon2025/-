const products = [
    { id: 1, name: "메리골드 위시", price: "59,900원", img: "ca_img01.png" },
    { id: 2, name: "화이트 블러시", price: "59,900원", img: "ca_img02.png" },
    { id: 3, name: "피치 골드 플라워", price: "49,900원", img: "ca_img03.png" },
    { id: 4, name: "메리골드 위시", price: "59,900원", img: "ca_img01.png" },
    { id: 5, name: "화이트 블러시", price: "59,900원", img: "ca_img02.png" },
    { id: 6, name: "피치 골드 플라워", price: "49,900원", img: "ca_img03.png" },
    { id: 7, name: "메리골드 위시", price: "59,900원", img: "ca_img01.png" },
    { id: 8, name: "화이트 블러시", price: "59,900원", img: "ca_img02.png" },
    { id: 9, name: "피치 골드 플라워", price: "49,900원", img: "ca_img03.png" },
    { id: 10, name: "메리골드 위시", price: "59,900원", img: "ca_img01.png" },
    { id: 11, name: "화이트 블러시", price: "59,900원", img: "ca_img02.png" },
    { id: 12, name: "피치 골드 플라워", price: "49,900원", img: "ca_img03.png" },
];

export default products;
