import { createContext, useState, useEffect } from "react";

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
    // localStorage에서 초기값 불러오기
    const [items, setItems] = useState(() => {
        try {
            const saved = localStorage.getItem("cartItems");
            return saved ? JSON.parse(saved) : [];
        } catch (e) {
            console.error("localStorage parsing error:", e);
            return [];
        }
    });

    // items가 바뀔 때 localStorage에 저장
    useEffect(() => {
        localStorage.setItem("cartItems", JSON.stringify(items));
    }, [items]);

    // 아이템 추가
    const addItem = (newItem) => {
        setItems((prevItems) => {
            const existingIndex = prevItems.findIndex(
                (item) =>
                    item.id === newItem.id &&
                    item.optionLabel === newItem.optionLabel &&
                    item.deliveryType === newItem.deliveryType
            );

            if (existingIndex !== -1) {
                const updatedItems = prevItems.map((item, idx) =>
                    idx === existingIndex
                        ? {
                            ...item,
                            qty: item.qty + newItem.qty,
                            optionQty: (item.optionQty || 0) + (newItem.optionQty || 0),
                        }
                        : item
                );
                return updatedItems;
            } else {
                return [...prevItems, newItem];
            }
        });
    };

    // 선택상품 삭제
    const removeItems = (keysToRemove) => {
        setItems((prevItems) =>
            prevItems.filter(
                (item) =>
                    !keysToRemove.includes(`${item.id}-${item.deliveryType}`)
            )
        );
    };

    return (
        <CartContext.Provider value={{ items, setItems, addItem, removeItems }}>
            {children}
        </CartContext.Provider>
    );
};
