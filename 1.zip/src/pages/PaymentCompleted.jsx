import "./css/PaymentCompleted.css";
import { useNavigate, Link, useLocation } from "react-router-dom";
import { useEffect, useState, useContext } from "react";
import { CartContext } from "../CartContext"; // CartContext import

export default function PaymentCompleted({ loggedInUser }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { removeItems } = useContext(CartContext); // removeItems 사용

  const paidItems = location.state?.paidItems || [
    {
      id: 1,
      name: "메리골드 위시",
      price: 12000,
      status: "결제 완료",
      img: "https://kjwon2025.github.io/pinaimg/cartimg1.png",
      mainCount: 1,
      optionPrice: 0,
      optionCount: 0,
      totalPrice: 12000,
      deliveryType: "normal",
      optionLabel: "",
    },
  ];

  const removeKeys = location.state?.removeKeys || []; // MessageCard에서 전달한 삭제 키

  useEffect(() => {
    // 결제 완료 시 장바구니에서 삭제
    if (removeKeys.length > 0) {
      removeItems(removeKeys);
    }

    // 주문 정보를 localStorage에 저장
    const discountAmount = location.state?.discountAmount || 0;
    const finalTotal =
      location.state?.finalTotal ||
      paidItems.reduce((acc, it) => acc + it.totalPrice, 0);

    // 오늘 날짜 계산
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, "0");
    const dd = String(now.getDate()).padStart(2, "0");
    const today = `${yyyy}.${mm}.${dd}`;

    localStorage.setItem(
      "latestOrder",
      JSON.stringify({
        id: "2025-000001",
        items: paidItems,
        discountAmount,
        finalTotal,
        date: today, // 하드코딩 대신 오늘 날짜 사용
      })
    );
  }, [removeItems, removeKeys, paidItems, location.state]);

  const [showEventModal, setShowEventModal] = useState(false);
  const [confetti, setConfetti] = useState([]);
  const [event, setEvent] = useState(null);

  const goCategoryDetail = () => navigate("/CategoryDetail");

  useEffect(() => {
    // 이벤트 모달 랜덤 발생
    const timer = setTimeout(() => {
      if (Math.random() < 0.8) {
        const eventOptions = [
          {
            img: "https://kjwon2025.github.io/pinaimg/pce_flower.png",
            title: "이벤트 당첨!",
            text: "튤립 한 송이를 함께 보내드립니다!",
          },
          {
            img: "https://kjwon2025.github.io/pinaimg/pce_flower2.png",
            title: "이벤트 당첨!",
            text: "유리 화병을 함께 보내드립니다!",
          },
          {
            img: "https://kjwon2025.github.io/pinaimg/pce_flower3.png",
            title: "이벤트 당첨!",
            text: "미니 화분을 함께 보내드립니다!",
          },
        ];
        const randomEvent =
          eventOptions[Math.floor(Math.random() * eventOptions.length)];
        if (loggedInUser?.name) {
          randomEvent.title = `${loggedInUser.name}님, ${randomEvent.title}`;
        }
        setEvent(randomEvent);
        setShowEventModal(true);
      }
    }, 100);

    return () => clearTimeout(timer);
  }, [loggedInUser]);

  // 컨페티
  useEffect(() => {
    if (showEventModal) {
      const confettiArray = [];
      for (let i = 0; i < 100; i++) {
        confettiArray.push({
          id: i,
          left: Math.random() * 100 + "vw",
          size: 5 + Math.random() * 10 + "px",
          bg: `hsl(${Math.random() * 360}, 100%, 50%)`,
          delay: Math.random() * 2 + "s",
          duration: 3 + Math.random() * 3 + "s",
          rotate: Math.random() * 360 + "deg",
        });
      }
      setConfetti(confettiArray);
    } else {
      setConfetti([]);
    }
  }, [showEventModal]);

  const closeModal = () => setShowEventModal(false);

  const [today, setToday] = useState("");

  useEffect(() => {
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, "0"); // 월은 0부터 시작
    const dd = String(now.getDate()).padStart(2, "0");
    setToday(`${yyyy}.${mm}.${dd}`);
  }, []);

  return (
    <>
      <div id="sec1allPC">
        <h1 className="sec1titlePC">결제 완료</h1>
        <div className="sec1contentPC">
          <div className="contenttopPC">
            <img
              src={
                paidItems[0]?.img ||
                "https://kjwon2025.github.io/pinaimg/pc_flower.png"
              }
              alt={paidItems[0]?.productName || "상품 이미지"}
            />
          </div>
          <div className="contentbottomPC">
            <div className="completePC">주문이 완료되었습니다!</div>
            <div className="completenumPC">
              <br /> 주문번호: 2025-000001
            </div>
            <div className="cpdatePC">{today}</div>
            {paidItems.length > 0 && (
              <div className="paiditemnamePC">
                <ul>
                  {paidItems.map((item, idx) => (
                    <li key={idx}>{item.productName || item.name}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
        <div id="sec1bottomPC">
          <Link to={"/Orderlist"}>
            <button className="sec1buttonleftPC">주문내역 보기</button>
          </Link>
          <button className="sec1buttonrightPC" onClick={goCategoryDetail}>
            계속 쇼핑하기
          </button>
        </div>
      </div>

      {confetti.map((c) => (
        <div
          key={c.id}
          className="confetti"
          style={{
            left: c.left,
            width: c.size,
            height: c.size,
            backgroundColor: c.bg,
            animationDelay: c.delay,
            animationDuration: c.duration,
            transform: `rotate(${c.rotate})`,
          }}
        />
      ))}

      <div
        id="paymenteventPCE"
        className={`modalOverlay ${showEventModal ? "show" : ""}`}
        onClick={closeModal}
      >
        <div
          className="modalContentPCE prize"
          onClick={(e) => e.stopPropagation()}
        >
          {event && (
            <>
              <img src={event.img} alt="event_image" />
              <h2 className="h2PCE sparkle">{event.title}</h2>
              <p className="ptextPCE sparkle">{event.text}</p>
            </>
          )}
          <button onClick={closeModal}>닫기</button>
        </div>
      </div>
    </>
  );
}
