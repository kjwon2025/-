import { useState, useEffect, useContext } from "react";
import { CartContext } from "../CartContext";
import "./css/Payment.css";
import { useNavigate, useLocation } from "react-router-dom";

const formatKRW = (n) => n.toLocaleString("ko-KR");

export default function PaymentPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const [userCoupons, setUserCoupons] = useState([]);
  const storedUser = JSON.parse(localStorage.getItem("loggedInUser"));
  const userId = storedUser?.id;
  const { removeItems } = useContext(CartContext);

  // MessageCard 또는 Detail에서 전달된 상품 정보
  const {
    productName = "메리골드 위시",
    price = 59900,
    mainCount = 1,
    optionName = "크리스탈 화병",
    optionPrice = 12000,
    optionCount = 1,
    deliveryType = "일반배송",
    totalPrice = price * mainCount + optionPrice * optionCount,
    cartItems = [], // MessageCard에서 전달한 배열
    img, // 디테일에서 넘어오는 상품 이미지
    selectedKeys = [],
  } = location.state || {};

  // 화면에 표시할 상품 배열
  const products =
    cartItems.length > 0
      ? cartItems.map((item) => ({
          productName: item.productName || item.name,
          price: item.price,
          mainCount: item.mainCount ?? item.qty,
          optionName: item.optionName ?? item.optionLabel,
          optionPrice: item.optionPrice,
          optionCount: item.optionCount ?? item.optionQty ?? 0,
          deliveryType: item.deliveryType || "일반배송",
          totalPrice:
            item.totalPrice ??
            item.price * (item.mainCount ?? item.qty) +
              item.optionPrice * (item.optionCount ?? item.optionQty ?? 0),
          img:
            item.img || "https://kjwon2025.github.io/pinaimg/paymentimg1.png",
        }))
      : [
          {
            productName,
            price,
            mainCount,
            optionName,
            optionPrice,
            optionCount,
            deliveryType,
            totalPrice:
              (price || 59900) * (mainCount || 1) +
              (optionPrice || 12000) * (optionCount || 1),
            img: img || "https://kjwon2025.github.io/pinaimg/paymentimg1.png",
          },
        ];

  const [buyer, setBuyer] = useState({ name: "", phone: "" });
  const [sender, setSender] = useState({ name: "" });
  const [receiver, setReceiver] = useState({
    name: "",
    phone: "",
    address: "",
  });
  const [coupon, setCoupon] = useState("");
  const [payMethod, setPayMethod] = useState("card");
  const [cardInfo, setCardInfo] = useState({
    num1: "",
    num2: "",
    num3: "",
    num4: "",
    year: "",
    month: "",
    pw: "",
  });

  const handleSubmit = (e) => {
    e.preventDefault();

    const sumTotal = products.reduce(
      (acc, item) =>
        acc +
        (item.totalPrice ??
          item.price * item.mainCount + item.optionPrice * item.optionCount),
      0
    );

    // ✅ 사용한 쿠폰 제거
    if (selectedCoupon && userId) {
      const storedCoupons =
        JSON.parse(localStorage.getItem(`coupons_${userId}`)) || [];
      const updatedCoupons = storedCoupons.filter(
        (c) => c.text !== selectedCoupon.text
      );
      localStorage.setItem(`coupons_${userId}`, JSON.stringify(updatedCoupons));
    }

    // ✅ 장바구니에서 결제한 상품 삭제
    if (cartItems.length > 0) {
      const keysToRemove = cartItems.map((it) => `${it.id}-${it.deliveryType}`);
      removeItems(keysToRemove); // CartContext에서 삭제
    }

    // 결제 완료 페이지로 이동
    navigate("/PaymentCompleted", {
      state: {
        paidItems: products,
        discountAmount,
        finalTotal,
      },
    });
  };

  useEffect(() => {
    if (userId) {
      const storedCoupons =
        JSON.parse(localStorage.getItem(`coupons_${userId}`)) || [];
      setUserCoupons(storedCoupons);
    }
  }, [userId]);

  const [selectedCoupon, setSelectedCoupon] = useState(null);

  // 총 결제금액 계산
  const sumTotal = products.reduce(
    (acc, item) =>
      acc +
      (item.totalPrice ??
        item.price * item.mainCount + item.optionPrice * item.optionCount),
    0
  );

  // 쿠폰 적용
  let finalTotal = sumTotal;
  let discountAmount = 0;

  if (selectedCoupon) {
    // 핀아 개발 비용 후원 쿠폰이면 금액 추가
    if (selectedCoupon.text.includes("핀아 개발 비용 후원")) {
      finalTotal = sumTotal + 300000;
      discountAmount = -300000; // 음수로 표시 가능
    } else {
      const percentMatch = selectedCoupon.text.match(/(\d+)%/);
      const wonMatch = selectedCoupon.text.match(/([\d,]+)원/);

      if (percentMatch) {
        const percent = parseInt(percentMatch[1], 10);
        discountAmount = Math.floor(sumTotal * (percent / 100));
      } else if (wonMatch) {
        discountAmount = parseInt(wonMatch[1].replace(/,/g, ""), 10);
      }
      finalTotal = Math.max(0, sumTotal - discountAmount);
    }
  }

  const [couponModalVisible, setCouponModalVisible] = useState(false);

  return (
    <>
      <div id="s1PM">
        <div id="s1conPM">
          <h1 className="h1PM">주문 결제</h1>

          <div className="conboxPM">
            <h2 className="h2PM">주문 내역</h2>

            {products.map((item, idx) => (
              <div className="subcon1PM" key={idx}>
                <div className="sc1iboxPM">
                  <img
                    src={
                      item.img ||
                      "https://kjwon2025.github.io/pinaimg/paymentimg1.png"
                    }
                    alt={item.productName || item.name}
                  />
                </div>
                <div className="sc1infoPM">
                  {/* 배송방법 표시 */}
                  <div className="delihowPM">
                    {item.deliveryType === "오늘배송" ? "오늘배송" : "일반배송"}
                  </div>

                  <span className="infoboldPM">
                    {item.productName || item.name}
                  </span>
                  <span className="infoinfoPM">
                    {formatKRW(item.price)}원 / 수량 : {item.mainCount ?? 0}개
                    <br />
                    {item.optionName ?? item.optionLabel} (+
                    {formatKRW(item.optionPrice)}원 x {item.optionCount ?? 0})
                  </span>
                  <span className="infoboldPM">
                    총{" "}
                    {formatKRW(
                      item.totalPrice ??
                        item.price * item.mainCount +
                          item.optionPrice * item.optionCount
                    )}
                    원
                  </span>
                </div>
              </div>
            ))}

            <form className="buyformPM" onSubmit={handleSubmit}>
              <h3 className="h31PM">주문자 정보</h3>
              <div className="buyinfoPM">
                <span>이름</span>
                <input
                  type="text"
                  className="biidPM"
                  placeholder="이름을 입력해주세요."
                  value={buyer.name}
                  onChange={(e) => setBuyer({ ...buyer, name: e.target.value })}
                />
                <span>연락처</span>
                <input
                  type="tel"
                  className="biphonePM"
                  placeholder="연락처를 입력해주세요."
                  value={buyer.phone}
                  onChange={(e) =>
                    setBuyer({ ...buyer, phone: e.target.value })
                  }
                />
              </div>

              <h3 className="h32PM">발신인</h3>
              <div className="sendPM">
                <span>이름</span>
                <input
                  type="text"
                  className="snPM"
                  placeholder="이름을 입력해주세요."
                  value={sender.name}
                  onChange={(e) => setSender({ name: e.target.value })}
                />
              </div>

              <div className="pitbPM">
                <h3 className="h33PM">배송지 정보</h3>
                <div className="picbPM">
                  <input
                    type="checkbox"
                    id="directInput"
                    checked={true}
                    onChange={(e) => e.preventDefault()}
                  />
                  <label htmlFor="directInput">받는 분이 직접 입력</label>
                </div>
              </div>

              <div className="placeinfoPM">
                <span>받는 분 이름</span>
                <input
                  type="text"
                  className="piidPM"
                  placeholder="받는 분 이름을 입력해주세요."
                  value={receiver.name}
                  onChange={(e) =>
                    setReceiver({ ...receiver, name: e.target.value })
                  }
                />
                <span>전화번호</span>
                <input
                  type="tel"
                  className="piphonePM"
                  placeholder="전화번호를 입력해주세요."
                  value={receiver.phone}
                  onChange={(e) =>
                    setReceiver({ ...receiver, phone: e.target.value })
                  }
                />
                <span>주소</span>
                <input
                  type="text"
                  className="piaddressPM"
                  placeholder="주소를 입력해주세요."
                  value={receiver.address}
                  onChange={(e) =>
                    setReceiver({ ...receiver, address: e.target.value })
                  }
                />
              </div>

              <h3 className="h35PM">쿠폰</h3>
              <div className="couponPM">
                <span>쿠폰 할인</span>
                <div className="cpinfoPM">
                  <div className="currentcpboxPM">
                    <input
                      type="text"
                      className="cpcodePM"
                      placeholder="쿠폰을 선택해 주세요."
                      value={coupon}
                      readOnly // 사용자가 직접 입력하지 않고 선택하도록
                    />
                    <button
                      type="button"
                      className="cpresetPM"
                      onClick={() => {
                        setCoupon(""); // input 초기화
                        setSelectedCoupon(null); // 선택 쿠폰 초기화
                      }}
                    >
                      선택취소
                    </button>
                  </div>
                  <button
                    type="button"
                    className="slcpbtn"
                    onClick={() => setCouponModalVisible(true)}
                  >
                    쿠폰선택
                  </button>
                </div>
                {couponModalVisible && (
                  <div
                    className="couponModal"
                    onClick={() => setCouponModalVisible(false)}
                  >
                    <div
                      className="couponModalContent"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <h3>사용 가능한 쿠폰 선택</h3>
                      {userCoupons.length === 0 ? (
                        <p className="nocptext">보유한 쿠폰이 없습니다.</p>
                      ) : (
                        <ul>
                          {userCoupons.map((c, idx) => {
                            const isSelected = selectedCoupon?.text === c.text; // 선택 여부
                            return (
                              <li
                                key={idx}
                                className="selectcpPM"
                                onClick={() => {
                                  setCoupon(c.text); // input에 쿠폰 표시
                                  setSelectedCoupon(c); // 할인 적용용 선택 쿠폰 설정
                                  setCouponModalVisible(false); // 모달 닫기
                                }}
                              >
                                <input
                                  type="checkbox"
                                  readOnly
                                  checked={isSelected} // 선택 여부 반영
                                />
                                <span>
                                  {c.text} (
                                  {new Date(c.issuedAt).toLocaleDateString()}{" "}
                                  발급)
                                </span>
                              </li>
                            );
                          })}
                        </ul>
                      )}
                      <button
                        type="button"
                        className="modalclosePM"
                        onClick={() => setCouponModalVisible(false)}
                      >
                        닫기
                      </button>
                    </div>
                  </div>
                )}
              </div>

              <h3 className="h36PM">결제 수단 선택</h3>
              <div className="paywayPM">
                <div className="pwbtnboxPM">
                  <button
                    type="button"
                    className={`pwbtn1PM ${
                      payMethod === "card" ? "selectedPM" : ""
                    }`}
                    onClick={() => setPayMethod("card")}
                  >
                    신용카드
                  </button>
                  <button
                    type="button"
                    className={`pwbtn2PM ${
                      payMethod === "bank" ? "selectedPM" : ""
                    }`}
                    onClick={() => setPayMethod("bank")}
                  >
                    무통장 입금
                  </button>
                </div>

                {payMethod === "card" && (
                  <>
                    <span>신용카드 번호 (직접 입력)</span>
                    <div className="pwcardPM">
                      <input
                        type="text"
                        maxLength="4"
                        value={cardInfo.num1}
                        onChange={(e) =>
                          setCardInfo({ ...cardInfo, num1: e.target.value })
                        }
                        required
                      />
                      <input
                        type="password"
                        maxLength="4"
                        value={cardInfo.num2}
                        onChange={(e) =>
                          setCardInfo({ ...cardInfo, num2: e.target.value })
                        }
                        required
                      />
                      <input
                        type="password"
                        maxLength="4"
                        value={cardInfo.num3}
                        onChange={(e) =>
                          setCardInfo({ ...cardInfo, num3: e.target.value })
                        }
                        required
                      />
                      <input
                        type="text"
                        maxLength="4"
                        value={cardInfo.num4}
                        onChange={(e) =>
                          setCardInfo({ ...cardInfo, num4: e.target.value })
                        }
                        required
                      />
                    </div>

                    <span>유효기간 (년/월)</span>
                    <div className="pwymPM">
                      <input
                        type="number"
                        placeholder="YYYY"
                        value={cardInfo.year}
                        onChange={(e) =>
                          setCardInfo({ ...cardInfo, year: e.target.value })
                        }
                      />
                      <input
                        type="number"
                        placeholder="MM"
                        value={cardInfo.month}
                        onChange={(e) =>
                          setCardInfo({ ...cardInfo, month: e.target.value })
                        }
                        required
                      />
                    </div>

                    <span>비밀번호 앞 두자리</span>
                    <input
                      type="password"
                      maxLength="2"
                      value={cardInfo.pw}
                      onChange={(e) =>
                        setCardInfo({ ...cardInfo, pw: e.target.value })
                      }
                      className="pwnum2PM"
                      required
                    />
                  </>
                )}
              </div>

              {payMethod === "bank" && (
                <div className="bankInfoPM">
                  <h4>무통장 입금 안내</h4>
                  <p>
                    주문 후 아래 계좌로 입금해주셔야 주문이 완료됩니다.
                    <br />
                    <strong>입금 계좌 :</strong> 국민은행 123-4567-8901-23
                    (예금주: 핀아)
                    <br />
                    <strong>입금 기한 :</strong> 주문 후 24시간 이내
                  </p>
                  <p className="bankNoticePM">
                    입금자명과 주문자명이 다를 경우 고객센터로 꼭 연락주세요.
                  </p>
                </div>
              )}

              <div className="pwagreetextPM">
                <span>
                  이용약관 및 개인정보 처리방침에 대해 확인하였으며 결제에
                  동의합니다.
                  <br />
                  <br />
                  배송안내
                  <br />
                  배송일, 배송지 변경은 '발송대기' 상태에서만 가능합니다.
                  <br />
                  자연재해로 인하여 교통 및 기상 상황이 좋지 못할 경우, 배송이
                  지연될 수 있는 점 양해 부탁드립니다.
                  <br />
                  <br />
                  오늘배송 안내
                  <br />
                  오늘배송 주문의 특성상 '발송 준비중' 상태에서 취소와 주소지
                  변경이 어렵습니다.
                  <br />
                  필요시 고객센터로 즉시 연락해주세요.
                </span>
              </div>

              <div className="totalPricePM">
                <button type="submit" className="pwlastbtnPM">
                  {formatKRW(finalTotal)}원 결제하기
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}
