import { useState, useContext } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { CartContext } from "../CartContext"; // CartContext import
import "./css/MessageCard.css";

export default function MessageCard() {
  const navigate = useNavigate();
  const location = useLocation();
  const { items } = useContext(CartContext); // CartContext 사용

  const {
    cartItems,
    productName = "메리골드 위시",
    price = 59900,
    mainCount = 1,
    optionName = "크리스탈 화병",
    optionPrice = 12000,
    optionCount = 1,
    deliveryType,
    img,
    detailVersion = "1",
  } = location.state || {};

  const products =
    cartItems && cartItems.length > 0
      ? cartItems.map((item) => ({
          id: item.id, // 삭제용 key 유지
          optionLabel: item.optionLabel,
          deliveryType: item.deliveryType,
          productName: item.name,
          price: item.price,
          mainCount: item.qty,
          optionName: item.optionLabel,
          optionPrice: item.optionPrice,
          optionCount: item.optionQty || 0,
          img: item.img || "https://kjwon2025.github.io/pinaimg/dt_flower1.png",
        }))
      : [
          {
            id: 0, // 단일 상품용 id
            optionLabel: optionName,
            deliveryType,
            productName,
            price,
            mainCount,
            optionName,
            optionPrice,
            optionCount,
            img: img || "https://kjwon2025.github.io/pinaimg/dt_flower1.png",
          },
        ];

  const grandTotal = products.reduce(
    (sum, item) =>
      sum + item.price * item.mainCount + item.optionPrice * item.optionCount,
    0
  );

  const categories = [
    { name: "DIY", img: "https://kjwon2025.github.io/pinaimg/mc_card.png" },
    {
      name: "사랑하는 당신에게",
      img: "https://kjwon2025.github.io/pinaimg/mc_card2.png",
    },
    {
      name: "삼가 조의를 표합니다.",
      img: "https://kjwon2025.github.io/pinaimg/mc_card3.png",
    },
    {
      name: "Happy BirthDay !",
      img: "https://kjwon2025.github.io/pinaimg/mc_card4.png",
    },
    {
      name: "내가 널 응원해 !",
      img: "https://kjwon2025.github.io/pinaimg/mc_card5.png",
    },
  ];

  const [category, setCategory] = useState(categories[0].name);
  const [message, setMessage] = useState("");

  const handleCategoryChange = (e) => setCategory(e.target.value);
  const handleMessageChange = (e) => {
    if (e.target.value.length <= 250) setMessage(e.target.value);
  };

  const handleSubmit = () => {
    // 결제페이지로 cartItems와 삭제용 키 전달
    navigate("/payment", {
      state: {
        cartItems: products,
        productName: products[0].productName,
        price: products[0].price,
        mainCount: products[0].mainCount,
        optionName: products[0].optionName,
        optionPrice: products[0].optionPrice,
        optionCount: products[0].optionCount,
        totalPrice: grandTotal,
        deliveryType: products.map((item) => item.deliveryType),
        removeKeys: products.map(
          (item) => `${item.id}-${item.deliveryType}-${item.optionLabel}`
        ), // 삭제용 key
      },
    });
    window.scrollTo(0, 0);
  };

  const selectedImage = categories.find((cat) => cat.name === category)?.img;
  const detailImg =
    detailVersion === "1"
      ? "https://kjwon2025.github.io/pinaimg/dt_detail1.png"
      : "https://kjwon2025.github.io/pinaimg/dt_detail1-2.png";

  return (
    <div>
      {/* 섹션1 */}
      <div id="sec1allMC">
        <h1 className="sec1titleMC">메세지 카드 작성하기</h1>

        <div className="product-listMC">
          {products.map((item, idx) => {
            const totalPrice =
              item.price * item.mainCount + item.optionPrice * item.optionCount;
            return (
              <div key={idx} className="product-itemMC">
                <div className="sec1leftMC">
                  <img src={item.img} alt={item.productName} />
                </div>
                <div className="sec1rightMC">
                  <div className="delivery-typeMC">
                    {item.deliveryType === "오늘배송" ? "오늘배송" : "일반배송"}
                  </div>
                  <div className="itemnameMC">{item.productName}</div>
                  <div className="item-detailMC">
                    <div>
                      {item.price.toLocaleString()}원 x {item.mainCount}개
                      {item.optionCount > 0 && (
                        <div className="optionMC">
                          {item.optionName}(+{item.optionPrice.toLocaleString()}
                          원 x {item.optionCount})
                        </div>
                      )}
                    </div>
                    <div className="itempriceMC">
                      합계 {totalPrice.toLocaleString()}원
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="grand-totalMC">
          총 합계 : {grandTotal.toLocaleString()}원
        </div>
      </div>

      {/* 섹션2 */}
      <div id="sec2allMC">
        <div className="sec2topMC">
          {categories.map((cat, idx) => {
            const checkboxId = `category-${idx}`;
            return (
              <label
                key={cat.name}
                className="circle-checkboxMC"
                htmlFor={checkboxId}
              >
                <input
                  type="checkbox"
                  name="category"
                  value={cat.name}
                  checked={category === cat.name}
                  onChange={handleCategoryChange}
                  id={checkboxId}
                />
                {cat.name}
              </label>
            );
          })}
        </div>
        <div className="sec2bottomMC">
          <div className="sec2bottomleftMC">
            <img src={selectedImage} alt={category} />
          </div>
          <div className="sec2bottomrightMC">
            <div className="input-containerMC">
              <textarea
                id="messageMC"
                value={message}
                onChange={handleMessageChange}
                maxLength={250}
                placeholder="내용을 입력해주세요."
              />
              <div className="char-countMC">
                <span id="charCountMC">{message.length}</span>/250
              </div>
            </div>
          </div>
        </div>
        <div id="sec2-2allboxMC">
          <br />- 최대 10줄, 한 줄당 최대 26자까지 인쇄됩니다. (공백 포함)
          <br />- 이모티콘은 편지 내용에 포함되지 않습니다.
          <br />- 한국어와 영어 이외의 다른 외국어는 사용이 어렵습니다.
        </div>
      </div>

      {/* 섹션3 */}
      <div id="sec3MC">
        <button className="doneMC" onClick={handleSubmit}>
          작성완료
        </button>
      </div>
    </div>
  );
}
