import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./css/Orderlist.css";

const formatKRW = (n) => n.toLocaleString("ko-KR");

export default function OrderList() {
  const [orders, setOrders] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const latestOrder = localStorage.getItem("latestOrder");
    if (latestOrder) {
      setOrders([JSON.parse(latestOrder)]);
    }
  }, []);

  const goBrowse = () => navigate("/CategoryDetail");

  return (
    <div id="s1OL">
      <div id="s1boxOL">
        <h1 className="h1OL">주문 내역</h1>

        {/* 주문내역 없는 경우 */}
        {(!orders || orders.length === 0) && (
          <div id="s1noneOL">
            <div id="noneboxOL">
              <div className="nonecontentOL">
                <span className="nonespanOL">주문내역이 없습니다.</span>
                <div className="noneitembtnOL" role="button" onClick={goBrowse}>
                  상품 구경하기
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 주문내역 있는 경우 */}
        {orders &&
          orders.length > 0 &&
          orders.map((order) => {
            const total = order.items.reduce(
              (acc, it) =>
                acc +
                (it.totalPrice ??
                  it.price * (it.mainCount || 1) +
                    it.optionPrice * (it.optionCount || 0)),
              0
            );

            return (
              <div className="s1content1OL" key={order.id}>
                <div className="conbox1OL">
                  <div>
                    주문번호
                    <br />
                    {order.id}
                  </div>
                  <br />
                  <div>
                    주문일
                    <br />
                    {order.date}
                  </div>
                </div>

                <div className="conbox2OL">
                  {order.items.map((it, i) => (
                    <div key={i} className="itemboxOL">
                      <div className="itemimgOL">
                        <img src={it.img} alt={it.productName || it.name} />
                        <div
                          className="rvbtnOL"
                          role="button"
                          onClick={() => {
                            if (it.productName.includes("메리")) {
                              navigate("/detail", {
                                state: { openReview: true },
                              });
                            } else if (it.productName.includes("화이트")) {
                              navigate("/detail2", {
                                state: { openReview: true },
                              });
                            }
                          }}
                        >
                          리뷰 쓰기
                        </div>
                      </div>
                      <div className="itemnameOL">
                        {it.productName || it.name}
                      </div>
                      <div className="itempriceOL">
                        {formatKRW(
                          it.totalPrice - it.optionCount * it.optionPrice
                        )}
                        원
                        <span>
                          ( 옵션 가격:{" "}
                          {formatKRW(it.optionPrice * it.optionCount)}원 )
                        </span>
                      </div>
                      <div className="itemdlvOL">
                        {it.deliveryType === "오늘배송"
                          ? "오늘배송"
                          : "일반배송"}
                      </div>
                      <div className="itemtotalOL">
                        합계:{" "}
                        {formatKRW(
                          it.totalPrice ??
                            it.price * (it.mainCount || 1) +
                              it.optionPrice * (it.optionCount || 0)
                        )}
                        원
                      </div>
                    </div>
                  ))}
                </div>

                <div className="conbox3OL">
                  총 합계 : {formatKRW(order.finalTotal)}원
                  {order.discountAmount > 0 && (
                    <span
                      style={{
                        color: "#2E5245",
                        marginLeft: "10px",
                        fontSize: "15px",
                        fontWeight: "500",
                      }}
                    >
                      ( 쿠폰 할인 : - {formatKRW(order.discountAmount)}원 )
                    </span>
                  )}
                  {order.discountAmount < 0 && (
                    <span
                      style={{
                        color: "#2E5245",
                        marginLeft: "10px",
                        fontSize: "15px",
                        fontWeight: "500",
                      }}
                    >
                      ( 후원 금액 : {formatKRW(-order.discountAmount)}원 )
                    </span>
                  )}
                </div>
              </div>
            );
          })}
      </div>
    </div>
  );
}
