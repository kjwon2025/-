import { useMemo, useContext, useState } from "react";
import { CartContext } from "../CartContext.js";
import { useNavigate } from "react-router-dom";
import "./css/Cart.css";

const formatKRW = (n) => n.toLocaleString("ko-KR");

export default function CartPage() {
  const { items, setItems, removeItems } = useContext(CartContext);
  const [selectedItems, setSelectedItems] = useState([]);
  const navigate = useNavigate();

  // 총 합계 계산
  const total = useMemo(
    () =>
      items.reduce((acc, it) => {
        const key = `${it.id}-${it.deliveryType}`;
        return selectedItems.includes(key)
          ? acc + it.price * it.qty + it.optionPrice * (it.optionQty || 0)
          : acc;
      }, 0),
    [items, selectedItems]
  );

  // 수량 변경
  const changeQty = (id, deliveryType, delta) => {
    setItems((prev) =>
      prev.map((it) =>
        it.id === id && it.deliveryType === deliveryType
          ? { ...it, qty: Math.max(1, it.qty + delta) }
          : it
      )
    );
  };

  // 옵션 수량 변경
  const changeOptionQty = (id, deliveryType, delta) => {
    setItems((prev) =>
      prev.map((it) =>
        it.id === id && it.deliveryType === deliveryType
          ? { ...it, optionQty: Math.max(0, (it.optionQty || 0) + delta) }
          : it
      )
    );
  };

  // 체크박스 선택 토글
  const toggleSelect = (id, deliveryType) => {
    const key = `${id}-${deliveryType}`;
    setSelectedItems((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  // 선택상품 삭제
  const removeSelected = () => {
    removeItems(selectedItems); // CartContext에서 삭제
    setSelectedItems([]); // 체크박스 초기화
  };

  // 장바구니 비었을 때
  if (!items || items.length === 0) {
    return (
      <div id="s1noneCT">
        <div id="noneboxCT">
          <h1 className="noneh1CT">장바구니</h1>
          <div className="nonecontentCT">
            <span className="nonespanCT">담겨진 상품이 없습니다.</span>
            <div
              className="noneitembtnCT"
              role="button"
              onClick={() => navigate("/CategoryDetail")}
            >
              상품 구경하기
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div id="s1CT" style={{ minHeight: items.length === 1 ? "563px" : "auto" }}>
      <div id="s1boxCT">
        <h1 className="h1CT">장바구니</h1>
        <div className="cartitemCT">
          <div className="s1contentCT">
            <div className="ctc1CT">
              {items.map((it) => {
                const key = `${it.id}-${it.deliveryType}`;
                return (
                  <div key={key}>
                    {/* 체크박스 */}
                    <div className="checkconCT">
                      <input
                        type="checkbox"
                        checked={selectedItems.includes(key)}
                        onChange={() => toggleSelect(it.id, it.deliveryType)}
                        id={`chch-${key}`}
                      />
                      <label htmlFor={`chch-${key}`}>상품 선택</label>
                    </div>

                    {/* 상품 박스 */}
                    <div
                      className="productBoxCT"
                      style={{ display: "flex", alignItems: "center" }}
                    >
                      {/* 이미지 */}
                      <div className="cartimgCT">
                        <img src={it.img} alt={`${it.name} 이미지`} />
                      </div>

                      {/* 상품 정보 */}
                      <div className="iteminfoCT">
                        <span className="infospanCT">
                          {it.name}
                          <br />
                          {formatKRW(it.price)}원
                        </span>
                        <div className="pnmboxCT" aria-label="수량 조절">
                          <button
                            type="button"
                            className="pnm-btn minus"
                            onClick={() =>
                              changeQty(it.id, it.deliveryType, -1)
                            }
                          >
                            -
                          </button>
                          <span className="pnmcountCT">{it.qty}</span>
                          <button
                            type="button"
                            className="pnm-btn plus"
                            onClick={() =>
                              changeQty(it.id, it.deliveryType, +1)
                            }
                          >
                            +
                          </button>
                        </div>
                      </div>

                      {/* 옵션 */}
                      <div className="optCT">
                        <span className="optinfoCT">
                          {it.optionLabel}
                          <br />
                          {formatKRW(it.optionPrice)}원
                        </span>
                        <div className="pnmboxCT" aria-label="옵션 수량 조절">
                          <button
                            type="button"
                            className="pnm-btn minus"
                            onClick={() =>
                              changeOptionQty(it.id, it.deliveryType, -1)
                            }
                          >
                            -
                          </button>
                          <span className="pnmcountCT">
                            {it.optionQty ?? 0}
                          </span>
                          <button
                            type="button"
                            className="pnm-btn plus"
                            onClick={() =>
                              changeOptionQty(it.id, it.deliveryType, +1)
                            }
                          >
                            +
                          </button>
                        </div>
                      </div>

                      <div className="itemoptpCT">
                        <span className="iopinfoCT">
                          <div className="deliinfoCT">{it.deliveryType}</div>
                          <br />
                          {formatKRW(
                            it.price * it.qty +
                              it.optionPrice * (it.optionQty || 0)
                          )}
                          원
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* 합계 */}
        <div
          className="ctc2CT"
          style={{
            height:
              items.length === 1
                ? "185px"
                : items.length === 2
                ? "431px"
                : items.length === 3
                ? "677px"
                : items.length === 4
                ? "923px"
                : "185px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <span className="totalpriceCT">합계 {formatKRW(total)}원</span>
        </div>

        {/* 버튼 */}
        <div className="btnsCT">
          <button
            className="removebtnCT"
            type="button"
            onClick={removeSelected}
            disabled={selectedItems.length === 0}
          >
            선택상품 삭제하기
          </button>

          <button
            className="buybtnCT"
            type="button"
            onClick={() => {
              if (selectedItems.length === 0) {
                alert("상품을 선택해주세요.");
              } else {
                navigate("/MessageCard", {
                  state: {
                    cartItems: items
                      .filter((it) =>
                        selectedItems.includes(`${it.id}-${it.deliveryType}`)
                      )
                      .map((it) => ({
                        ...it, // 기존 데이터 유지
                        id: it.id, // ✅ 반드시 id 포함
                        deliveryType: it.deliveryType, // ✅ 반드시 deliveryType 포함
                      })),
                  },
                });
              }
            }}
          >
            선택상품 결제하기
          </button>
        </div>
      </div>
    </div>
  );
}
