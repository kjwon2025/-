import "./css/CategoryDetail.css";
import { useState, useMemo } from "react";
import { useNavigate, useLocation } from "react-router-dom"; // 🔹 useLocation 추가
import { useDispatch, useSelector } from "react-redux";
import {
  selectCurrentItems,
  selectTotalPages,
  selectActivePage,
  setPage,
  nextPage,
  prevPage,
} from "../store/productsSlice";
import { togglePriceFilter } from "../store/productsSlice";

import productsData from "../data/CategoryDetailProduct";

import { useEffect } from "react";

const img = (name) => `https://kjwon2025.github.io/pinaimg/${name}`;

function CategoryDetail() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const location = useLocation(); // 🔹 현재 URL 정보 가져오기

  //가격 필터링
  const [priceFilterState, setPriceFilterState] = useState({
    over5: false,
    "3to5": false,
    under3: false,
  });

  // ✅ Redux에서 상품 데이터 가져오기
  const itemsFromRedux = useSelector(selectCurrentItems);

  // ✅ Redux에서 현재 페이지 가져오기
  const activePage = useSelector(selectActivePage); // <-- 여기 추가
  const items = productsData;

  // 🔹 URL에서 search 파라미터 가져오기
  const searchParams = new URLSearchParams(location.search);
  const rawKeyword = searchParams.get("search") || "";
  const searchKeyword = decodeURIComponent(rawKeyword);

  const filteredItems = useMemo(() => {
    return productsData.filter((product) => {
      // 가격 필터
      let pricePass = true;
      const priceNum = Number(product.price.replace(/[^0-9]/g, ""));
      const activePriceFilters = Object.entries(priceFilterState)
        .filter(([_, v]) => v)
        .map(([key]) => key);

      if (activePriceFilters.length > 0) {
        pricePass = activePriceFilters.some((filter) => {
          if (filter === "over5") return priceNum >= 50000;
          if (filter === "3to5") return priceNum >= 30000 && priceNum <= 50000;
          if (filter === "under3") return priceNum <= 30000;
          return false;
        });
      }

      // 검색 필터
      let searchPass = true;
      if (searchKeyword) {
        const nameMatch = product.name.toLowerCase().includes(searchKeyword);
        const descriptionMatch = Array.isArray(product.description)
          ? product.description.some((d) =>
              d.toLowerCase().includes(searchKeyword)
            )
          : false;
        searchPass = nameMatch || descriptionMatch;
      }

      return pricePass && searchPass;
    });
  }, [priceFilterState, searchKeyword]);

  // ✅ filteredItems 계산 끝난 후 totalPagesCalculated 선언
  const itemsPerPage = 12;
  const totalPagesCalculated = Math.ceil(filteredItems.length / itemsPerPage);

  console.log("filteredItems:", filteredItems); // 여기서 출력
  console.log("totalPagesCalculated:", totalPagesCalculated); // 여기서 출력

  // 아코디언 상태
  const [sections, setSections] = useState({
    price: false,
    size: false,
    level: false,
  });

  const toggleSection = (key) =>
    setSections((prev) => ({ ...prev, [key]: !prev[key] }));

  // 페이지 번호를 5개씩 그룹핑
  const pagesPerGroup = 5;
  const pageGroup = Math.floor((activePage - 1) / pagesPerGroup);
  const startPage = pageGroup * pagesPerGroup + 1;
  // 페이지네이션 사용 시
  const endPage = Math.min(startPage + pagesPerGroup - 1, totalPagesCalculated);
  const pageNumbers = useMemo(
    () =>
      Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i),
    [startPage, endPage]
  );

  const currentPageItems = filteredItems.slice(
    (activePage - 1) * itemsPerPage,
    activePage * itemsPerPage
  );

  const rowsOf3 = useMemo(() => {
    return currentPageItems.reduce((rows, product, idx) => {
      if (idx % 3 === 0) rows.push([]);
      rows[rows.length - 1].push(product);
      return rows;
    }, []);
  }, [currentPageItems]);

  return (
    <>
      {/* 타이틀 */}
      <div id="ca_title">
        <h1>꽃 &gt; 꽃다발</h1>
      </div>

      <div id="ca_section01">
        {/* 필터 영역 */}
        <div className="ca_filter">
          {/* 가격 */}
          <div className="ca_price ca_arco">
            <button
              type="button"
              className="check_price check_title"
              onClick={() => toggleSection("price")}
            >
              가격
              <span
                className={`iconamoon--arrow-down-2-light ${
                  sections.price ? "open" : ""
                }`}
              />
            </button>
            <ul className={`caPanel ${sections.price ? "open" : ""}`}>
              <li>
                <label>
                  <input
                    type="checkbox"
                    checked={priceFilterState.over5}
                    onChange={() =>
                      setPriceFilterState((prev) => ({
                        ...prev,
                        over5: !prev.over5,
                      }))
                    }
                  />
                  5만원 이상
                </label>
              </li>
              <li>
                <label>
                  <input
                    type="checkbox"
                    checked={priceFilterState["3to5"]}
                    onChange={() =>
                      setPriceFilterState((prev) => ({
                        ...prev,
                        "3to5": !prev["3to5"],
                      }))
                    }
                  />
                  3 ~ 5만원
                </label>
              </li>
              <li>
                <label>
                  <input
                    type="checkbox"
                    checked={priceFilterState.under3}
                    onChange={() =>
                      setPriceFilterState((prev) => ({
                        ...prev,
                        under3: !prev.under3,
                      }))
                    }
                  />
                  3만원 이하
                </label>
              </li>
            </ul>
          </div>

          {/* 크기 */}
          <div className="ca_size ca_arco">
            <button
              type="button"
              className="check_size check_title"
              onClick={() => toggleSection("size")}
            >
              크기
              <span
                className={`iconamoon--arrow-down-2-light ${
                  sections.size ? "open" : ""
                }`}
              />
            </button>
            <ul className={`caPanel ${sections.size ? "open" : ""}`}>
              <li>
                <label>
                  <input type="checkbox" />
                  50cm 이상
                </label>
              </li>
              <li>
                <label>
                  <input type="checkbox" />
                  20cm ~ 50cm
                </label>
              </li>
              <li>
                <label>
                  <input type="checkbox" />
                  20cm 이하
                </label>
              </li>
            </ul>
          </div>

          {/* 난이도 */}
          <div className="ca_level ca_arco">
            <button
              type="button"
              className="check_level check_title"
              onClick={() => toggleSection("level")}
            >
              난이도
              <span
                className={`iconamoon--arrow-down-2-light ${
                  sections.level ? "open" : ""
                }`}
              />
            </button>
            <ul className={`caPanel ${sections.level ? "open" : ""}`}>
              <li>
                <label>
                  <input type="checkbox" />상
                </label>
              </li>
              <li>
                <label>
                  <input type="checkbox" />중
                </label>
              </li>
              <li>
                <label>
                  <input type="checkbox" />하
                </label>
              </li>
            </ul>
          </div>
        </div>

        {/* 상품 리스트 */}
        <div className="ca_products">
          {rowsOf3.map((row, rowIdx) => (
            <div
              key={rowIdx}
              className={`ca_products0${rowIdx + 1} ca_prostyle`}
            >
              {Array.from({ length: 3 }).map((_, idx) => {
                const product = row[idx];
                const isLastRow = rowIdx === rowsOf3.length - 1;

                if (!product) {
                  return (
                    <div key={`empty-${idx}`} style={{ width: "250px" }} />
                  );
                }

                const productIndex = (activePage - 1) * 12 + rowIdx * 3 + idx;

                return (
                  <div key={product.id} className="product_wrapper">
                    <div
                      className="product_card"
                      onClick={() => {
                        if (productIndex === 0)
                          navigate("/detail"); // 첫 번째 상품
                        else if (productIndex === 1) navigate("/detail2"); // 두 번째 상품
                      }}
                      style={{
                        cursor: productIndex <= 1 ? "pointer" : "default",
                      }}
                    >
                      <img src={img(product.img)} alt={product.name} />
                      <p className="product_name">{product.name}</p>
                      <p className="product_price">{product.price}</p>
                      {!isLastRow && <div className="ca_line"></div>}
                    </div>
                    {idx !== 2 && <div className="ca_widthLine"></div>}
                  </div>
                );
              })}
            </div>
          ))}

          {filteredItems.length === 0 && (
            <p style={{ textAlign: "center", marginTop: "20px" }}>
              검색 결과가 없습니다.
            </p>
          )}

          {/* 페이지네이션 */}
          <div className="ca_page">
            <ul>
              <li>
                <button
                  type="button"
                  className="linklike"
                  onClick={() => dispatch(setPage(1))}
                  disabled={activePage === 1}
                >
                  &lsaquo;&lsaquo;
                </button>
              </li>
              <li>
                <button
                  type="button"
                  className="linklike"
                  onClick={() => dispatch(prevPage())}
                  disabled={activePage === 1}
                >
                  &lsaquo;
                </button>
              </li>
              {pageNumbers.map((num) => (
                <li key={num}>
                  <button
                    type="button"
                    className={`linklike caLike ${
                      activePage === num ? "active" : ""
                    }`}
                    onClick={() => dispatch(setPage(num))}
                  >
                    {num}
                  </button>
                </li>
              ))}
              <li>
                <button
                  type="button"
                  className="linklike"
                  onClick={() => dispatch(nextPage())}
                  disabled={activePage === totalPagesCalculated}
                >
                  &rsaquo;
                </button>
              </li>
              <li>
                <button
                  type="button"
                  className="linklike"
                  onClick={() => dispatch(setPage(totalPagesCalculated))}
                  disabled={activePage === totalPagesCalculated}
                >
                  &rsaquo;&rsaquo;
                </button>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}

export default CategoryDetail;
