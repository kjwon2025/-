const products = [
    { id: 1, name: "메리골드 위시", price: "59,900원", img: "ca_img01.png", description: ["화사함", "주황", "노랑"] },
    { id: 2, name: "화이트 블러시", price: "59,900원", img: "ca_img02.png", description: ["발랄함", "핑크", "화이트"] },
    { id: 3, name: "허니 골드 플라워", price: "49,900원", img: "ca_img03.png", description: ["골드", "노랑", "데이트"] },
    { id: 4, name: "로맨틱 로즈", price: "59,900원", img: "ca_img04.png", description: ["선물", "강렬함", "장미"] },
    { id: 5, name: "코스모스 드림", price: "69,900원", img: "ca_img05.png", description: ["노랑", "옐로우", "큐트"] },
    { id: 6, name: "블루벨 판타지", price: "49,900원", img: "ca_img06.png", description: ["파랑", "힙함", "화사함"] },
    { id: 7, name: "릴리러브유", price: "89,900원", img: "ca_img07.png", description: ["백합", "독특", "하나"] },
    { id: 8, name: "레드 오션", price: "59,900원", img: "ca_img08.png", description: ["파랑", "힙함", "화사함"] },
    { id: 9, name: "레인보우샤벳", price: "49,900원", img: "ca_img09.png", description: ["무지개", "다양", "화사함"] },
    { id: 10, name: "메리골드", price: "59,900원", img: "ca_img10.png", description: ["단일", "주황", "깔끔"] },
    { id: 11, name: "밀크티컬렉션", price: "39,900원", img: "ca_img11.png", description: ["차분", "심플", "드라이플라워"] },
    { id: 12, name: "피치피치핏치", price: "19,900원", img: "ca_img12.png", description: ["복숭아", "주황", "노랑"] },
    { id: 13, name: "로맨스 로즈가든", price: "19,900원", img: "ca_img04.png", description: ["장미", "로맨틱", "프로포즈"] },
    { id: 14, name: "코스모스 가든", price: "19,900원", img: "ca_img05.png", description: ["꽃", "잔꽃", "큐티"] },
];

export default products;
