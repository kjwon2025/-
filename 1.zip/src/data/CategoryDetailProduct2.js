const products = [
    {
        id: 1,
        name: "스킨답서스",
        price: "54,000원",
        img: "s1img1.jpg",
        description: ["실내식물", "공기정화", "초보자추천"]
    },
    {
        id: 2,
        name: "파키라",
        price: "110,000원",
        img: "s1img6.jpg",
        description: ["행운목", "풍수인테리어", "개업선물"]
    },
    {
        id: 3,
        name: "산세베리아 젤라니카",
        price: "68,000원",
        img: "s1img8.jpg",
        description: ["공기정화", "강인함", "인테리어"]
    },
    {
        id: 4,
        name: "아가베 아테누아타",
        price: "238,000원",
        img: "s2p1-2.jpg",
        description: ["이국적", "럭셔리", "포인트식물"]
    },
    {
        id: 5,
        name: "페페로",
        price: "69,900원",
        img: "cd_02.jpg",
        description: ["귀여움", "미니식물", "책상용"]
    },
    {
        id: 6,
        name: "하트 스투키 선인장",
        price: "31,000원",
        img: "s2p2-2.jpg",
        description: ["하트모양", "선인장", "선물추천"]
    },
    {
        id: 7,
        name: "뱅갈고무나무",
        price: "78,000원",
        img: "s2p3-2.jpg",
        description: ["인테리어", "심플", "공기정화"]
    },
    {
        id: 8,
        name: "올리브나무",
        price: "73,000원",
        img: "s2p5-2.jpg",
        description: ["행복", "유럽풍", "심볼트리"]
    },
    {
        id: 9,
        name: "유칼립투스 폴리안",
        price: "108,000원",
        img: "s2p4-2.jpg",
        description: ["향기식물", "차분함", "드라이플라워"]
    },
    {
        id: 10,
        name: "접란",
        price: "68,000원",
        img: "s1img3.jpg",
        description: ["초보자추천", "공기정화", "튼튼함"]
    },
    {
        id: 11,
        name: "아라리아",
        price: "56,000원",
        img: "cd_05.jpg",
        description: ["우아함", "그린인테리어", "프리미엄"]
    },
    {
        id: 12,
        name: "필로덴드론 뷰티",
        price: "19,900원",
        img: "cd_03.jpg",
        description: ["저렴이", "미니식물", "책상용"]
    },
    {
        id: 13,
        name: "휘카스 움베르타",
        price: "163,000원",
        img: "cd_04.jpg",
        description: ["고급스러움", "대형식물", "인테리어"]
    },
    {
        id: 14,
        name: "미리오 클라두스",
        price: "47,000원",
        img: "cd_06.jpg",
        description: ["플라워", "화사함", "장식용"]
    },
];

export default products;
