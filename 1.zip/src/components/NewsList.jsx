import { useState, useEffect } from "react";
import axios from "axios";

import NewsItem from "./NewsItem";
import "./css/NewsList.css";

const NewsList = () => {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // ❌ 제외 키워드: 정치, 트럼프, 스포츠, 범죄, 시위
  const excludeKeywords = [
    // 한국어
    "정치",
    "트럼프",
    "스포츠",
    "범죄",
    "시위",
    "시위대",
    // 영어
    "politics",
    "trump",
    "sport",
    "crime",
    "criminal",
    "protest",
    "demonstration",
    "riot",
    "violence",
    "murder",
    "theft",
    "robbery",
    "football",
    "NFL",
    "touchdown",
    "quarterback",
    "SEC",
    "basketball",
    "soccer",
    "tennis",
    "Olympics",
    "match",
    "game",
    "riot",
    "demonstrators",
    "march",
    "protesters",
    "Cardi B",
  ];

  // ✅ 우선순위 키워드: 식물, 꽃, 기후, 환경, 정원
  const priorityKeywords = [
    // 한국어
    "식물",
    "꽃",
    "기후",
    "환경",
    "정원",
    // 영어
    "plant",
    "plants",
    "flower",
    "flowers",
    "climate",
    "climatic",
    "greenhouse",
    "photosynthesis",
    "botany",
    "horticulture",
    "environment",
    "ecology",
    "sustainability",
    "conservation",
    "garden",
    "gardening",
    "landscaping",
    "flora",
    "fauna",
    "trees",
    "shrubs",
    "herbs",
    "perennials",
    "annuals",
    "pollination",
    "biodiversity",
    "organic",
    "soil",
    "compost",
    "mulch",
    "irrigation",
    "greenery",
    "ecosystem",
    "weather",
    "sun",
    "sunny",
    "cloudy",
    "rain",
    "snow",
    "water",
  ];

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);

      try {
        const fromDate = new Date();
        fromDate.setDate(fromDate.getDate() - 7);
        const fromDateStr = fromDate.toISOString().split("T")[0];

        const response = await axios.get(
          `https://newsapi-68cj.onrender.com/news?category=general&fromDate=${fromDateStr}`
        );

        let filtered = response.data.articles || [];

        // 1️⃣ 제외 키워드 필터링
        filtered = filtered.filter((article) => {
          const content = `${article.title || ""} ${
            article.description || ""
          }`.toLowerCase();
          return !excludeKeywords.some((kw) =>
            content.includes(kw.toLowerCase())
          );
        });

        // 2️⃣ 우선순위 키워드 뉴스 상단 배치
        filtered.sort((a, b) => {
          const aContent = `${a.title || ""} ${
            a.description || ""
          }`.toLowerCase();
          const bContent = `${b.title || ""} ${
            b.description || ""
          }`.toLowerCase();

          const aPriority = priorityKeywords.some((kw) =>
            aContent.includes(kw.toLowerCase())
          )
            ? 1
            : 0;
          const bPriority = priorityKeywords.some((kw) =>
            bContent.includes(kw.toLowerCase())
          )
            ? 1
            : 0;

          return bPriority - aPriority;
        });

        setArticles(filtered);
      } catch (e) {
        console.error(
          "뉴스 API 호출 실패:",
          e.response ? e.response.data : e.message
        );
        setError("뉴스 데이터를 불러오는 중 오류가 발생했습니다.");
      }

      setLoading(false);
    };

    fetchData();
  }, []);

  if (loading) return <div className="news-list-block">대기중...</div>;
  if (error) return <div className="news-list-block">{error}</div>;
  if (!articles.length)
    return <div className="news-list-block">뉴스가 없습니다.</div>;

  return (
    <div className="news-list-block">
      {articles.slice(0, 4).map((article) => (
        <NewsItem key={article.url} article={article} />
      ))}
    </div>
  );
};

export default NewsList;
