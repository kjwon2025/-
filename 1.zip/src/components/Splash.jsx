import { useState, useEffect } from "react";
import "./css/Splash.css";

export default function Splash({ onFinish }) {
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setFadeOut(true);
      setTimeout(() => {
        if (onFinish) onFinish();
      }, 1800);
    }, 4000);

    return () => clearTimeout(timer);
  }, [onFinish]);

  const handleClick = () => {
    setFadeOut(true);
    setTimeout(() => {
      if (onFinish) onFinish();
    }, 1800);
  };

  return (
    <div id="wrapSP" className={fadeOut ? "fadeOut" : ""} onClick={handleClick}>
      <video
        className="vSP"
        autoPlay
        loop
        muted
        src="https://kjwon2025.github.io/pinaimg/splash.mp4"
        type="video/mp4"
      />
      <button className="gomainbtnSP">PIN-A</button>
    </div>
  );
}
