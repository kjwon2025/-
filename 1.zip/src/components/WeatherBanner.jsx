import { useState, useEffect } from "react";
import "./css/WeatherBanner.css";

const API_KEY = "1ac517df27cdf8836585f85daf01a89b";

const WeatherBanner = () => {
  const [weather, setWeather] = useState(null);

  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const response = await fetch(
          `https://api.openweathermap.org/data/2.5/weather?lat=37.3084&lon=126.851&appid=${API_KEY}&units=metric&lang=kr`
        );
        const data = await response.json();
        setWeather(data);
      } catch (error) {
        console.error("날씨 불러오기 실패:", error);
      }
    };
    fetchWeather();
  }, []);

  // 날씨 이미지를 선택
  const getWeatherImage = () => {
    if (!weather)
      return `https://kjwon2025.github.io/pinaimg/default-weather.png`;
    const main = weather.weather[0].main.toLowerCase();
    if (main.includes("clear"))
      return `https://kjwon2025.github.io/pinaimg/weather1.png`; // 맑음
    if (main.includes("cloud"))
      return `https://kjwon2025.github.io/pinaimg/weather2.png`; // 흐림
    if (main.includes("rain"))
      return `https://kjwon2025.github.io/pinaimg/weather3.png`; // 비
    return `https://kjwon2025.github.io/pinaimg/default-weather.png`;
  };

  // 단순화된 날씨 텍스트
  const getSimpleWeatherText = () => {
    if (!weather) return "";
    const main = weather.weather[0].main.toLowerCase();
    if (main.includes("clear")) return "맑음";
    if (main.includes("cloud")) return "흐림";
    if (main.includes("rain")) return "비";
    return "알 수 없음";
  };

  return (
    <div
      className="custom-banner active"
      style={{
        backgroundImage: `url(${getWeatherImage()})`,
        backgroundPosition: "center",
      }}
    >
      {weather ? (
        <div className="weather-info">
          <h2>현재 날씨 : {getSimpleWeatherText()}</h2>
          <p>
            온도 :<br />
            {weather.main.temp}°C / 체감 {weather.main.feels_like}°C
          </p>
          <br />
          <p>
            최저/최고 :<br />
            {weather.main.temp_min}°C / {weather.main.temp_max}°C
          </p>
          <br />
          <p>습도 : {weather.main.humidity}%</p>
          <p>바람 : {weather.wind.speed} m/s</p>
          <p>구름 : {weather.clouds.all}%</p>
        </div>
      ) : (
        <p>날씨 정보를 불러오는 중...</p>
      )}
    </div>
  );
};

export default WeatherBanner;
