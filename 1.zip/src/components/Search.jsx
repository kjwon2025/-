import React, { useRef, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "./css/Search.css";

// 두 카테고리 상품 데이터
import productsCategory1 from "../data/CategoryDetailProduct";
import productsCategory2 from "../data/CategoryDetailProduct2";

const Search = ({ isActive, setIsActive }) => {
  const inputRef = useRef(null);
  const containerRef = useRef(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (isActive && inputRef.current) inputRef.current.focus();
  }, [isActive]);

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      const keyword = inputRef.current.value.trim().toLowerCase();

      const isCategoryDetailPage = location.pathname === "/CategoryDetail";
      const isCategoryDetail2Page = location.pathname === "/CategoryDetail2";

      // ✅ 빈 값 검색 시 처리
      if (keyword === "") {
        if (isCategoryDetailPage) {
          // CategoryDetail 페이지면 전체 상품 보여주기
          navigate(`/CategoryDetail`);
        } else if (isCategoryDetail2Page) {
          // CategoryDetail2 페이지면 전체 상품 보여주기
          navigate(`/CategoryDetail2`);
        } else {
          // 다른 페이지면 그대로 유지
          return;
        }
        return;
      }

      // ✅ 현재 페이지가 CategoryDetail 또는 CategoryDetail2라면
      if (isCategoryDetailPage) {
        navigate(`/CategoryDetail?search=${encodeURIComponent(keyword)}`);
        return;
      }

      if (isCategoryDetail2Page) {
        navigate(`/CategoryDetail2?search=${encodeURIComponent(keyword)}`);
        return;
      }

      // ✅ 현재 페이지가 다른 페이지일 때 → 어느 카테고리로 갈지 판단
      const matchInCategory2 = productsCategory2.some((product) => {
        const nameMatch = product.name.toLowerCase().includes(keyword);
        const descMatch = Array.isArray(product.description)
          ? product.description.some((desc) =>
              desc.toLowerCase().includes(keyword)
            )
          : product.description.toLowerCase().includes(keyword);
        return nameMatch || descMatch;
      });

      const matchInCategory1 = productsCategory1.some((product) => {
        const nameMatch = product.name.toLowerCase().includes(keyword);
        const descMatch = Array.isArray(product.description)
          ? product.description.some((desc) =>
              desc.toLowerCase().includes(keyword)
            )
          : product.description.toLowerCase().includes(keyword);
        return nameMatch || descMatch;
      });

      if (matchInCategory2) {
        navigate(`/CategoryDetail2?search=${encodeURIComponent(keyword)}`);
      } else if (matchInCategory1) {
        navigate(`/CategoryDetail?search=${encodeURIComponent(keyword)}`);
      } else {
        // 두 카테고리 모두 없으면 기본 CategoryDetail로 이동
        navigate(`/CategoryDetail?search=${encodeURIComponent(keyword)}`);
      }
    }
  };

  return (
    <div
      id="hdmsinputMP"
      className={isActive ? "active" : ""}
      ref={containerRef}
    >
      <div id="hdmsboxMP">
        <input
          type="text"
          placeholder="SEARCH 핀아"
          ref={inputRef}
          onKeyDown={handleKeyDown}
        />
      </div>
      <span>추천 검색어 : 스킨답서스, 파키라, 화이트 블러시</span>
    </div>
  );
};

export default Search;
