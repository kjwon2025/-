import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./css/Popup.css";

function Popup({ isOpen, onClose }) {
  const [dontShowToday, setDontShowToday] = useState(false);
  const [visible, setVisible] = useState(false); // 실제 렌더링 여부

  // 초기 로컬스토리지 확인
  useEffect(() => {
    const saved = localStorage.getItem("popupClosedUntil");
    if (saved && new Date(saved) > new Date()) {
      setVisible(false); // 오늘 닫기 체크되어 있으면 안보이게
    } else {
      setVisible(isOpen); // 기본값은 isOpen
    }
  }, [isOpen]);

  const handleClose = () => {
    if (dontShowToday) {
      const expireTime = new Date();
      expireTime.setHours(expireTime.getHours() + 24);
      localStorage.setItem("popupClosedUntil", expireTime.toISOString());
    }
    setVisible(false);
    onClose();
  };

  if (!visible) return null;

  return (
    <div className="popup-overlay">
      <div className="puclose">
        <input
          type="checkbox"
          id="pudayclose1"
          checked={dontShowToday}
          onChange={(e) => setDontShowToday(e.target.checked)}
        />
        <label htmlFor="pudayclose1">오늘 하루 열지 않기</label>
        <button onClick={handleClose} className="puclosebtn">
          닫기
        </button>
      </div>
      <div className="pucontainer">
        <div className="pucontents">
          <img
            src="https://kjwon2025.github.io/pinaimg/dt_etc3.png"
            alt="dt_etc3"
          />
          <span className="puspan1">
            *&nbsp;&nbsp;핀아 온라인 스토어 서비스 기념&nbsp;&nbsp;*
          </span>
          <span className="puspan2">
            각 종 할인쿠폰과 경품 이벤트 진행 중 !
          </span>
        </div>
        <Link to={"/Lottery"}>
          <button className="pulotbtn">경품추첨 바로가기</button>
        </Link>
      </div>
    </div>
  );
}

export default Popup;
