const AdMP = () => {
  return (
    <div
      id="adMP"
      style={{
        width: "100%",
        height: "250px",
        background: `url(https://kjwon2025.github.io/pinaimg/mpad.png) center/cover no-repeat`,
        marginBottom: "80px",
      }}
    ></div>
  );
};

export default AdMP;
