import { useState, useEffect, useRef } from "react";
import "./css/Banner.css";
import { useNavigate } from "react-router-dom";

const bannerImages = [
  "./img/banner1.png",
  "./img/banner2.png",
  "./img/banner3.png",
];

const Banner = () => {
  const [current, setCurrent] = useState(0);
  const [progressKey, setProgressKey] = useState(0); // 진행 바 키
  const navigate = useNavigate();
  const totalBanners = bannerImages.length;

  const intervalRef = useRef(null);

  const goCategoryDetail = () => {
    navigate("/CategoryDetail");
  };

  const startAutoSlide = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      setCurrent((prev) => (prev + 1) % totalBanners);
      setProgressKey((k) => k + 1); // 진행 바 애니메이션 초기화
    }, 4000);
  };

  useEffect(() => {
    startAutoSlide();
    return () => clearInterval(intervalRef.current);
  }, []);

  const handleButtonClick = (index, e) => {
    e.stopPropagation();
    setCurrent(index);
    setProgressKey((k) => k + 1); // 클릭 시 진행바 초기화
    startAutoSlide();
  };

  return (
    <div id="bannerMP" onClick={goCategoryDetail}>
      {bannerImages.map((src, index) => (
        <img
          key={index}
          src={src}
          alt={`banner${index + 1}`}
          className={current === index ? "active" : ""}
        />
      ))}

      <div id="bannerbtnbox">
        {[...Array(totalBanners)].map((_, index) => (
          <button
            key={index + "-" + progressKey} // key에 progressKey 포함
            className={index === current ? "progress active" : "progress"}
            onClick={(e) => handleButtonClick(index, e)}
          ></button>
        ))}
      </div>
    </div>
  );
};

export default Banner;
