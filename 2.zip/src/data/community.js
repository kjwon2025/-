const coWrite = [
    {
        productImg: "/img/co_img01.png",
        title: "꽃이 실제보다 너무 작아서 실망입니다.",
        content: "아니 꽃을 샀는데…<br /> 실제 사진보다 너무 작아서 좀 그렇습니다… <br />이건 좀 슬픕니다.",
        name: "박○○",
        date: "25.00.00",
        views: 33,
    },
    {
        productImg: "/img/co_img02.png",
        title: "화병 짱 예쁨",
        content: "내 화분을 바라봐<br /> 넌 내 꽃에 빠져<br /> 끝.",
        name: "장○○",
        date: "25.00.00",
        views: 173,
    },
    {
        productImg: "/img/co_img03.png",
        title: "꽃이 진짜 너무 예뻐요!",
        content: "고양이는 자랑이냐구요?<br />맞습니다! 잇힝 고양이 없는 사람 누구?<br />난 고양이 있다.",
        name: "박○○",
        date: "25.00.00",
        views: 1004,
    },
    {
        productImg: "/img/co_img04.png",
        title: "실제로 보니까 진짜 더 예뻐요",
        content: "분홍꽃이 역시 제일 예쁩니다.<br />종종 이용하겠습니다.<br />핀아 화이팅~",
        name: "전○○",
        date: "25.00.00",
        views: 50,
    },
    {
        productImg: "/img/co_img05.png",
        title: "산책하다 찍은 벚꽃 사진입니다.",
        content: "산책하다가 꽃을 찍었읍니다.<br />활짝 핀 이 꽃처럼 모두에게도 행복한 날만 있기를......<br /> 모두....행복합시다...!",
        name: "박○○",
        date: "25.00.00",
        views: 24,
    }
]

export default coWrite;