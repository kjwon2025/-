import { useState, useEffect } from "react";
import { Routes, Route, useLocation } from "react-router-dom";

import Splash from './components/Splash';
import Popup from './components/Popup';
import Section from './components/Section';
import Header from "./components/Header";
import Banner from "./components/Banner";
import SubButtons from "./components/SubButtons";
import Section1 from "./components/Section1";
import Section2 from "./components/Section2";
import WeatherBanner from "./components/WeatherBanner";
import Section3 from "./components/Section3";
import Section4 from "./components/Section4";
import Footer from "./components/Footer";
import Login from "./components/Login";
import NavChat from "./components/NavChat";
import ScrollToTop from "./components/ScrollToTop";
import AdMP from "./components/AdMP";
import News from './components/News'

import Member from './pages/Member';
import Cart from './pages/Cart';
import Orderlist from './pages/Orderlist';
import Payment from './pages/Payment';
import Detail from "./pages/Detail";
import Detail2 from "./pages/Detail2";
import Lottery from './pages/Lottery';
import Mypage from './pages/Mypage';
import MessageCard from './pages/MessageCard';
import PaymentCompleted from './pages/PaymentCompleted';
import BoardWrite from './pages/BoardWrite';
import QnA from './pages/QnA';
import CategoryDetail from './pages/CategoryDetail';
import Community from './pages/Community';

import { CartProvider } from "./CartContext";

function MainPage() {
    const [showPopup, setShowPopup] = useState(false);

    useEffect(() => {
        setShowPopup(true);
    }, []);

    return (
        <>
            <Popup isOpen={showPopup} onClose={() => setShowPopup(false)} />
            <Banner />
            <SubButtons />
            <Section><Section1 /></Section>
            <Section><Section2 /></Section>
            <WeatherBanner />
            <Section><Section3 /></Section>
            <Section><Section4 /></Section>
            <AdMP />
            <Section><News /></Section>
        </>
    );
}

function App() {
    const [loginActive, setLoginActive] = useState(false);
    const [loggedInUser, setLoggedInUser] = useState(null);
    const location = useLocation();
    const [showSplash, setShowSplash] = useState(location.pathname === "/");

    useEffect(() => {
        const storedUser = localStorage.getItem("loggedInUser");
        if (storedUser) setLoggedInUser(JSON.parse(storedUser));
    }, []);

    return (
        <>
            <ScrollToTop />

            {showSplash ? (
                <Splash onFinish={() => setShowSplash(false)} />
            ) : (
                <>
                    <Header openLogin={() => setLoginActive(true)} />

                    <CartProvider>
                        <Routes>
                            <Route path="/" element={<MainPage />} />
                            <Route path="/member" element={<Member />} />
                            <Route path="/Cart" element={<Cart />} />
                            <Route path="/Orderlist" element={<Orderlist />} />
                            <Route path="/Payment" element={<Payment />} />
                            <Route path="/Detail" element={<Detail />} />
                            <Route path="/Detail2" element={<Detail2 />} />
                            <Route path="/Lottery" element={<Lottery />} />
                            <Route path="/Mypage" element={<Mypage />} />
                            <Route path="/MessageCard" element={<MessageCard />} />
                            <Route path="/PaymentCompleted" element={<PaymentCompleted loggedInUser={loggedInUser} />} />
                            <Route path="/BoardWrite" element={<BoardWrite />} />
                            <Route path="/QnA" element={<QnA />} />
                            <Route path="/CategoryDetail" element={<CategoryDetail />} />
                            <Route path="/Community" element={<Community />} />
                        </Routes>
                    </CartProvider>
                    <Footer />

                    <Login
                        isActive={loginActive}
                        closeLogin={() => setLoginActive(false)}
                        setLoggedInUser={setLoggedInUser}
                    />

                    <NavChat />
                </>
            )}
        </>
    );
}

export default App;
