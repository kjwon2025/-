import { createContext, useState, useEffect } from "react";

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
    // localStorage에 저장된 값 불러오기
    const [items, setItems] = useState(() => {
        const saved = localStorage.getItem("cartItems");
        return saved ? JSON.parse(saved) : [];
    });

    // items가 바뀔 때 localStorage에도 저장
    useEffect(() => {
        localStorage.setItem("cartItems", JSON.stringify(items));
    }, [items]);

    const addItem = (newItem) => {
        setItems((prevItems) => {
            const existingIndex = prevItems.findIndex(
                (item) =>
                    item.id === newItem.id &&
                    item.optionLabel === newItem.optionLabel
            );

            if (existingIndex !== -1) {
                const updatedItems = [...prevItems];
                updatedItems[existingIndex] = {
                    ...updatedItems[existingIndex],
                    qty: updatedItems[existingIndex].qty + newItem.qty,
                    optionQty:
                        (updatedItems[existingIndex].optionQty || 0) +
                        (newItem.optionQty || 0),
                };
                return updatedItems;
            } else {
                return [...prevItems, newItem];
            }
        });
    };

    return (
        <CartContext.Provider value={{ items, setItems, addItem }}>
            {children}
        </CartContext.Provider>
    );
};
