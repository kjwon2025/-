// 한번 선택했는지 상태 + 펼침이 끝났는지 상태
let hasPicked = false;
let pickedCard = null;
let canPick = false;   // ⬅️ 펼침(퍼지기) 끝나야 true

// ------------------------------
// 1) 카드 뒤집기(한 번만 허용, 재뒤집기 금지 / 펼침 끝나야만 동작)
// ------------------------------
document.addEventListener('click', (e) => {
  const card = e.target.closest('.lo_card');
  if (!card) return;

  // 아직 펼침 완료 전이면 무시
  if (!canPick) return;

  // 이미 하나 뽑았으면 더 이상 동작 금지
  if (hasPicked) return;

  // 이미 뒤집힌 카드면 무시 (토글 금지)
  if (card.classList.contains('is-flipped')) return;

  // 최초 뒤집기 허용
  card.classList.add('is-flipped');
  pickedCard = card;
  hasPicked = true;

  // 전체 카드 클릭 막기
  document.querySelectorAll('.lo_card').forEach(c => c.classList.add('no-click'));

  // 뒤집힌 뒤 1초 후 모달 오픈
  scheduleOpenModal(card);
});


// ------------------------------
// 2) 시작: 중앙에 카드 9장 겹치기 → 2초 뒤 순차적으로 제자리 복귀
// ------------------------------
window.addEventListener('DOMContentLoaded', () => {
  const box = document.querySelector('.lo_cardBox');
  if (!box) return;

  const cards = Array.from(box.querySelectorAll('.lo_card'));
  if (!cards.length) return;

  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // 시작할 땐 선택 못 하게 잠금
  cards.forEach(c => c.classList.add('no-pick'));

  // 그리드 박스의 중앙 좌표
  const boxRect = box.getBoundingClientRect();
  const targetX = boxRect.left + boxRect.width / 2;
  const targetY = boxRect.top + boxRect.height / 2;

  // 각 카드의 현재(center → 카드 center) 델타 계산해서 중앙으로 겹치도록 세팅
  cards.forEach((card) => {
    const rect = card.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dx = targetX - cx;
    const dy = targetY - cy;

    card.style.setProperty('--dx', `${dx}px`);
    card.style.setProperty('--dy', `${dy}px`);
    card.classList.add('stacked');
  });

  // 창 크기 바뀌면, 아직 퍼지기 전(stacked 상태)에는 중앙 델타 재계산
  const recomputeIfStacked = () => {
    if (!cards[0].classList.contains('stacked')) return;
    const r = box.getBoundingClientRect();
    const tx = r.left + r.width / 2;
    const ty = r.top + r.height / 2;
    cards.forEach((card) => {
      const cr = card.getBoundingClientRect();
      const cx = cr.left + cr.width / 2;
      const cy = cr.top + cr.height / 2;
      card.style.setProperty('--dx', `${tx - cx}px`);
      card.style.setProperty('--dy', `${ty - cy}px`);
    });
  };
  window.addEventListener('resize', recomputeIfStacked);

  // 2초 대기 후, 순차적으로 퍼지기
  const START_DELAY = 2000; // ms
  const STAGGER = 150;      // 한 장씩 간격(ms)
  const TRANSITION_MS = 700; // .lo_card 의 transition 시간과 동일

  if (prefersReduced) {
    // 모션 줄이기: 바로 제자리 + 즉시 선택 가능
    cards.forEach((card) => card.classList.remove('stacked'));
    canPick = true;
    cards.forEach(c => c.classList.remove('no-pick'));
    return;
  }

  setTimeout(() => {
    cards.forEach((card, idx) => {
      setTimeout(() => {
        card.classList.remove('stacked'); // transform → none 으로 전환(transition)
      }, idx * STAGGER);
    });
  }, START_DELAY);

  // ✅ 모든 카드가 제자리로 돌아간 뒤 선택 가능 처리
  const totalMs = START_DELAY + STAGGER * (cards.length - 1) + TRANSITION_MS + 50; // 약간의 버퍼
  setTimeout(() => {
    canPick = true;                             // 이제부터 선택 가능
    cards.forEach(c => c.classList.remove('no-pick')); // 클릭 허용
  }, totalMs);
});


/* ===== 모달 생성 ===== */
let modalTimer = null;
let modalEl = null;

function ensureModal() {
  if (modalEl) return modalEl;

  modalEl = document.createElement('div');
  modalEl.id = 'lo_modal';
  modalEl.innerHTML = `
    <div class="lo_modalWrap" role="dialog" aria-modal="true">
      <div class="lo_modalHeader">
        <div class="name"></div>
        <div class="msg"></div>
      </div>
      <img class="lo_modalImg" alt="선택한 꽃 이미지" />
       <a href="#none" class="lo_coupon">10% 할인 쿠폰</a>
    </div>
    <div class="lo_modalFoot">
      <p class="lo_notice">*쿠폰은 00년 00월에 발행되며 앱에서만 사용 가능해요.</p>
    </div>
  `;
  document.body.appendChild(modalEl);

  // 바깥(배경) 클릭 시 닫기
  modalEl.addEventListener('click', (e) => {
    if (e.target === modalEl) closeModal();
  });

  // ESC로 닫기
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
  });

  return modalEl;
}

function scheduleOpenModal(card) {
  cancelScheduledModal();
  modalTimer = setTimeout(() => openModalFromCard(card), 1000); // 1초 대기
}

function cancelScheduledModal() {
  if (modalTimer) {
    clearTimeout(modalTimer);
    modalTimer = null;
  }
}

function openModalFromCard(card) {
  const overlay = ensureModal();

  // 뒷면 이미지 src
  const imgSrc = card.querySelector('.lo_cardBack img')?.src || '';
  // 꽃 이름: data-name 속성(없으면 기본 텍스트)
  const name = card.dataset.name || '꽃 이름';
  // 앞면 문구(두 줄)를 가져와서 “ … ” 형태로
  const frontTextEl = card.querySelector('.lo_cardText');
  const msgText = frontTextEl
    ? '“ ' + frontTextEl.innerText.trim().replace(/\s*\n\s*/g, ' ') + ' ”'
    : '“ 마음을 담아 ”';

  overlay.querySelector('.lo_modalImg').src = imgSrc;
  overlay.querySelector('.name').textContent = name;
  overlay.querySelector('.msg').textContent = msgText;

  overlay.classList.add('show');
}

function closeModal() {
  cancelScheduledModal();
  if (!modalEl) return;
  modalEl.classList.remove('show');
}
