
(function () {
    const PANELS = ".my_access .panel";
    const ORDERS_ID = "panel-orders";
    const COUPONS_ID = "panel-coupons";

    function showPanel(id) {
        document.querySelectorAll(PANELS).forEach((p) => {
            p.hidden = (p.id !== id);
        });
    }

    function getCurrentPanelId() {
        const p = Array.from(document.querySelectorAll(PANELS)).find(el => el.hidden === false);
        return p ? p.id : ORDERS_ID;
    }

    // 1) 명시적 트리거(.toggle-panel)로 열기
    document.querySelectorAll(".toggle-panel").forEach((el) => {
        el.addEventListener("click", function (e) {
            e.preventDefault();
            const id = this.dataset.panelTarget;
            if (id) showPanel(id);
        });
    });

    // 2) 쿠폰 패널이 열려 있을 때, 왼쪽 메뉴(.my_order) 아무거나 누르면 주문/배송으로 복귀
    document.querySelectorAll(".my_order").forEach((row) => {
        row.addEventListener("click", function () {
            // 만약 이 row 자체가 특정 패널을 열도록 지정됐다면(예: 쿠폰 메뉴) 그 동작 우선
            const target = this.dataset.panelTarget;
            if (target) {
                showPanel(target);
                return;
            }
            // 그 외의 경우, 현재 쿠폰 패널이면 주문/배송으로 복귀
            if (getCurrentPanelId() === COUPONS_ID) {
                showPanel(ORDERS_ID);
            }
        });
    });

    // (옵션) URL 해시로 들어온 경우 지원
    const hashId = location.hash.replace("#", "");
    if (hashId && document.getElementById(hashId)) {
        showPanel(hashId);
    }
})();